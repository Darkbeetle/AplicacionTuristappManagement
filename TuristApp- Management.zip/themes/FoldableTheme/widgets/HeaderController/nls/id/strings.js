define({
  "_widgetLabel": "Pengontrol Header",
  "signin": "Masuk",
  "signout": "Keluar",
  "about": "Tentang",
  "signInTo": "Masuk ke",
  "cantSignOutTip": "Fungsi ini tidak ada dalam mode pratinjau.",
  "more": "lebih banyak"
});